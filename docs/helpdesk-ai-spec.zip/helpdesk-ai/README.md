# helpdesk-ai

> Sistema de atendimento interno (substituto do GLPI) com triagem por IA, base de conhecimento RAG e fluxo de chamados completo. Inspirado no padrão visual e arquitetural do **BoardAdvisor** e do **FlowSDS**.

## Visão de produto

O colaborador entra na aplicação e vê seu dashboard pessoal. Quando precisa de suporte, **não preenche um formulário** — ele inicia um **bate-papo com um assistente de IA**, que faz uma triagem conversacional curta, consulta a base de conhecimento (RAG) e sugere ações de autoatendimento.

- Se a sugestão **resolve** → o "chamado" é fechado como auto-resolvido (com registro para métricas e enriquecimento da base).
- Se a sugestão **não resolve** → o chat é convertido em **ticket oficial**, já categorizado, com resumo gerado pela IA, contexto da conversa e anexos preservados.

O atendimento (fila, triagem, encaminhamento, resolução) é restrito ao time de TI.

## Personas

| Persona             | O que faz                                                                 |
|---------------------|--------------------------------------------------------------------------|
| **Colaborador**     | Abre chamados via chat com IA, acompanha próprios tickets, anexa arquivos |
| **Analista TI**     | Atende a fila, reatribui, responde, fecha chamados, alimenta base de conhecimento |
| **Gestor TI**       | Dashboards de SLA, volume, categorias, taxa de auto-resolução, satisfação |
| **Admin TI**        | Configurações (categorias, SLA, modelos de IA, prompts, RAG sources)      |

## Stack

- **Backend**: Python 3.12 + FastAPI + SQLAlchemy 2.x + Alembic + Pydantic v2
- **Frontend**: Next.js 16 (App Router) + React 19 + TypeScript + ShadCN UI + Tailwind + Zustand + TanStack Query
- **Banco**: PostgreSQL (schema `helpdesk` no cluster compartilhado `infra_postgres`)
- **Vetorial**: `pgvector` no mesmo Postgres (schema `helpdesk_rag`)
- **Storage**: MinIO compartilhado (`infra_minio`), bucket dedicado `helpdesk-attachments`
- **Auth**: schema `security` existente (usuários, grupos, sessões) — mesmo padrão usado pelas outras apps internas
- **LLM**:
  - Primário: **OpenAI GPT-5 mini** (configurável via env)
  - Fallback: **Anthropic Claude Haiku 4.5** (mesmo padrão do `notion-project-sync`)
- **Embeddings**: `text-embedding-3-small` (OpenAI) — 1536 dims
- **Observabilidade**: structlog + OpenTelemetry (OTLP) + Sentry
- **Deploy**: Docker Swarm em Hetzner CPX62 (mesma stack onde rodam as outras apps internas)

## Portas (proposta)

| Serviço            | Porta |
|--------------------|-------|
| Backend (FastAPI)  | 8004  |
| Frontend (Next.js) | 3004  |
| Postgres           | 5432 (compartilhado, schemas `helpdesk` e `helpdesk_rag`) |
| MinIO              | 9000 (compartilhado, bucket `helpdesk-attachments`)        |

## Estrutura do repositório (alvo)

```
helpdesk-ai/
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── core/                # config, logging, security, db
│   │   ├── domain/              # modelos SQLAlchemy + schemas Pydantic
│   │   ├── api/v1/              # routers REST
│   │   ├── services/
│   │   │   ├── tickets/         # workflow, SLA, atribuição
│   │   │   ├── ai/              # OpenAI + Anthropic + guardrails
│   │   │   ├── rag/             # ingestion, retrieval, reranking
│   │   │   └── auth/            # adapter para schema `security`
│   │   ├── workers/             # jobs assíncronos (ingestion, embeddings, notif)
│   │   └── tests/
│   ├── alembic/
│   ├── pyproject.toml
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── app/                 # Next.js App Router
│   │   ├── components/
│   │   ├── lib/
│   │   └── hooks/
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
├── docker-compose.prod.yml
├── docs/
│   ├── SPEC.md
│   ├── ARCHITECTURE.md
│   ├── SECURITY.md
│   ├── RAG_KNOWLEDGE_BASE.md
│   ├── PROMPTS.md
│   ├── DATABASE_SCHEMA.sql
│   └── adr/
└── CLAUDE.md
```

## Princípios de projeto

1. **Conversa primeiro, formulário depois.** Nada de campos obrigatórios na abertura. A IA extrai o que precisa.
2. **A IA é colega, não porteiro.** Ela tenta resolver; se não conseguir, abre o chamado. **Nunca** bloqueia o colaborador.
3. **TI atende, todos abrem.** RBAC simples: papel `it_agent` necessário para tudo que envolva fila/atendimento.
4. **Sem dados sensíveis no prompt.** Sanitização e PII tagging antes de enviar ao LLM (vide `SECURITY.md`).
5. **Prompt injection é tratado como entrada hostil por padrão.** Conteúdo de usuário sempre vai entre delimitadores e nunca como instrução.
6. **Auditoria total.** Toda interação com LLM, todo acesso a anexos, toda mudança de status é logada (`helpdesk.audit_log`).

## Documentos para o Claude Code

Leia nesta ordem antes de começar:

1. `docs/SPEC.md` — o que construir
2. `docs/ARCHITECTURE.md` — como estruturar
3. `docs/DATABASE_SCHEMA.sql` — modelo de dados
4. `docs/SECURITY.md` — guardrails obrigatórios
5. `docs/RAG_KNOWLEDGE_BASE.md` — pipeline de conhecimento
6. `docs/PROMPTS.md` — prompts iniciais (templates)
7. `CLAUDE.md` — convenções de código, testes, OPSEC
8. `prompts/bootstrap.md` — prompt inicial para iniciar o desenvolvimento

## Referências internas (paths locais)

- `/home/mateusfurrier/apps-staging/boardadvisor` — padrão visual (chat-first, shadcn), patterns de IA
- `/home/mateusfurrier/apps-staging/flowsds` — estrutura de stages, lanes, status workflow
